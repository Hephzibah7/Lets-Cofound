// Card.js
// import React from 'react';

// const PostCard = ({ imageUrl, text }) => {
  
//   return (
//     <div className="border rounded-lg overflow-hidden">
//       <img src={imageUrl} alt={text} className="w-full h-40 object-cover" />
//       <div className="p-4">
//         <p className="text-gray-800 text-lg font-semibold">{text}</p>
//       </div>
//     </div>
//   );
// };

// export default PostCard;
